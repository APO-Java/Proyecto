package consola;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;

import modulo.Cuarto;
import modulo.Hotel;
import modulo.Huesped;

public class Aplicacion {
	private static Hotel hotel = new Hotel("lelelo");
	
	private static void mostrarOpcionesDisponibles(String rol) {
		System.out.println("\n\tOpciones disponibles");
		if (rol.equals("administrador")) {
			System.out.println("1) Agregar o eliminar usuario");
			System.out.println("2) Modificar servicios");
			System.out.println("3) Modificar comidas o bebidas");
			System.out.println("4) Cargar archivo de habitaciones");
			System.out.println("5) Consultar servicios ");
			System.out.println("6) Consultar usuarios");
			System.out.println("7) Consultar menu");
			System.out.println("8) Consultar habitaciones");
			System.out.println("9) Consultar tipos de habitaciones");
			System.out.println("10) Log out");
		}
		else if (rol.equals("recepcionista")) {
			System.out.println("1) Crear reserva");
			System.out.println("2) Consultar habitaciones");
			System.out.println("3) Consultar informacion restaurante");
			System.out.println("4) Check out");
			System.out.println("5) Consultar consumos de una reserva");
			System.out.println("6) Consultar informacion servicios");
			System.out.println("7) Log out");
		}
		else {
			System.out.println("1) Registrar consumo");
			System.out.println("2) Consultar informacion restaurante");
			System.out.println("3) Consultar informacion servicios");
			System.out.println("4) Log out");
		}
		
	}
	
	private static String pedirUsuario() throws IOException {
		Boolean registrado = false;
		String rol = "";
		while (!registrado) {
			System.out.print("\nPor favor digite su login: ");
			BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
			String input = br.readLine();
			if(input == null) {
				System.out.println("\nLa entrada no puede estar vacia.");
			}
			else {
				String login = input;
				System.out.print("\nPor favor digite la contraseña: ");
				BufferedReader br1 = new BufferedReader (new InputStreamReader(System.in));
				String password = br1.readLine();
				if(password == null) {
					System.out.println("\nLa contraseña no puede estar vacia.");
				}
				else {
					rol = hotel.verificarUsuario(login, password);
					if (rol.equals("")) {
						System.out.println("\nUsuario o contraseña incorrectos");
					}
					else {
						registrado = true;
					}
				}
			}
		}
		return rol;
	}
	
	public static void ejecutarOpciones(int op, String rol) throws IOException, NumberFormatException, ParseException {
		if (rol.equals("administrador")) {
			if (op==1) {
				//String login, Boolean eliminar, String password, String rol
				System.out.print("\nPor favor digite el login: ");
				BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
				String login = br.readLine();
				System.out.print("\nPor favor digite E si va a eliminar o A si va a agregar: ");
				BufferedReader br1 = new BufferedReader (new InputStreamReader(System.in));
				String opcion = br1.readLine();
				if (opcion.equals("E")) {
					hotel.agregarEliminarUsuario(login, true, "", "");
					System.out.print("\nEl usuario ya no se encuentra en la base de datos");
				}
				else {
					System.out.print("\nPor favor digite el password: ");
					BufferedReader br2 = new BufferedReader (new InputStreamReader(System.in));
					String password = br2.readLine();
					System.out.print("\nPor favor digite el rol del usuario: ");
					BufferedReader br3 = new BufferedReader (new InputStreamReader(System.in));
					String rolNuevo = br3.readLine();
					hotel.agregarEliminarUsuario(login, false, password, rolNuevo);
				}
			}
			if (op==2) {
				//String nombre, int precio, Boolean personal
				System.out.print("\nPor favor digite el nombre del servicio: ");
				BufferedReader br4 = new BufferedReader (new InputStreamReader(System.in));
				String nombreServicio = br4.readLine();

				System.out.print("\nPor favor digite el precio del servicio: ");
				BufferedReader br5 = new BufferedReader (new InputStreamReader(System.in));
				String precio = br5.readLine();

				System.out.print("\nPor favor digite si el servicio es personal (P si lo es, cualquier otro caracter si no): ");
				BufferedReader br6 = new BufferedReader (new InputStreamReader(System.in));
				String personal = br6.readLine();
				Boolean pers = true;
				if (personal.equals("P")) {
					pers = true;
				}
				else {
					pers = false;
				}

				hotel.actualizarCrearServicio( nombreServicio,  Integer.parseInt(precio),  pers);
			}
			if (op==3) {
				//String nombrePlato, int nuevoPrecio, String lugarDisponibilidad, String disponibilidadComida
				System.out.print("\nPor favor digite si quiere actualizar una comida o bebida (0 si es comida y 1 si es bebida): ");
				BufferedReader br7 = new BufferedReader (new InputStreamReader(System.in));
				String opcional = br7.readLine();
				System.out.print("\nPor favor digite el nombre: ");
				BufferedReader br8 = new BufferedReader (new InputStreamReader(System.in));
				String nombre = br8.readLine();
				System.out.print("\nPor favor digite el precio: ");
				BufferedReader br9 = new BufferedReader (new InputStreamReader(System.in));
				String precio = br9.readLine();
				System.out.print("\nPor favor digite el lugar disponibilidad (restaurante habitacion; restaurante o habitacion): ");
				BufferedReader br10 = new BufferedReader (new InputStreamReader(System.in));
				String lugarDisponibilidad = br10.readLine();
				System.out.print("\nPor favor digite la disponibilidad (desayuno almuerzo comida y/o permamente) ");
				System.out.print("\nEntrada de ejemplo: desayuno almuerzo (el plato solo esta disponible en estas horas): ");
				BufferedReader br11 = new BufferedReader (new InputStreamReader(System.in));
				String tiempoDisponibilidad = br11.readLine();
				if (opcional.equals("0")) {
					hotel.actualizarCrearComida(nombre, Integer.parseInt(precio), lugarDisponibilidad, tiempoDisponibilidad);
				}
				else if(opcional.equals("1")){
					hotel.actualizarCrearBebida(nombre, Integer.parseInt(precio), lugarDisponibilidad, tiempoDisponibilidad);
				}
				else {
					System.out.print("\nLa opcion no existe ");
				}
			}
			if (op == 4) {
				System.out.print("\nPor favor digite el nombre del archivo (Ej: ./data/habitaciones.txt): ");
				BufferedReader br12 = new BufferedReader (new InputStreamReader(System.in));
				String path = br12.readLine();
				hotel.cargarCuartosActualizados(path);
			}
			if (op == 5) {
				System.out.println(hotel.listaServicios());
			}
			if (op==6) {
				System.out.println(hotel.listaUsuarios());
			}
			if (op==7) {
				System.out.println(hotel.listaMenu());
			}
			
			if (op==8) {
				System.out.println(hotel.listaCuartos());
			}
			
			if (op==9) {
				System.out.println(hotel.listaTiposHabitaciones());
			}
			
		}
		else if (rol.equals("recepcionista")) {
			if (op==1) {
				//int cedulaPrincipal, String fechaInit, String fechaFin, ArrayList<Huesped> huespedes,
				//ArrayList<Cuarto> cuartos
				System.out.println("\nIngrese el documento del huesped: ");
				BufferedReader br11 = new BufferedReader (new InputStreamReader(System.in));
				String documento = br11.readLine();
				
				System.out.println("\nIngrese el nombre del huesped: ");
				BufferedReader br12 = new BufferedReader (new InputStreamReader(System.in));
				String nombre = br12.readLine();
				
				System.out.println("\nIngrese el celular del huesped: ");
				BufferedReader br13 = new BufferedReader (new InputStreamReader(System.in));
				String celular = br13.readLine();
				
				System.out.println("\nIngrese el correo del huesped: ");
				BufferedReader br14 = new BufferedReader (new InputStreamReader(System.in));
				String correo = br14.readLine();
				
				System.out.println("\nIngrese la edad del huesped: ");
				BufferedReader br15 = new BufferedReader (new InputStreamReader(System.in));
				String edad = br15.readLine();
				
				Huesped huespedPrincipal = new Huesped( nombre,  Integer.parseInt(documento), Integer.parseInt(celular),
						 correo,  Integer.parseInt(edad));
				hotel.registrarHuesped( nombre,  Integer.parseInt(documento), Integer.parseInt(celular),
						 correo,  Integer.parseInt(edad));
				
				ArrayList<Huesped> huespedes = new ArrayList<Huesped>();
				
				huespedes.add(huespedPrincipal);
				Boolean anadir = true;
				while (anadir) {
					System.out.print("\nDesea añadir mas huespedes (digite si o no): ");
					BufferedReader br16 = new BufferedReader (new InputStreamReader(System.in));
					String anadir_ent = br16.readLine();
					if (anadir_ent.equals("si")) {
						System.out.println("\nIngrese el documento del huesped: ");
						br11 = new BufferedReader (new InputStreamReader(System.in));
						documento = br11.readLine();
						
						System.out.println("\nIngrese el nombre del huesped: ");
						br12 = new BufferedReader (new InputStreamReader(System.in));
						nombre = br12.readLine();
						
						System.out.println("\nIngrese el celular del huesped: ");
						br13 = new BufferedReader (new InputStreamReader(System.in));
						celular = br13.readLine();
						
						System.out.println("\nIngrese el correo del huesped: ");
						br14 = new BufferedReader (new InputStreamReader(System.in));
						correo = br14.readLine();
						
						System.out.println("\nIngrese la edad del huesped: ");
						br15 = new BufferedReader (new InputStreamReader(System.in));
						edad = br15.readLine();
						
						Huesped huesped = new Huesped( nombre,  Integer.parseInt(documento), Integer.parseInt(celular),
								 correo,  Integer.parseInt(edad));
						huespedes.add(huesped);	
						hotel.registrarHuesped( nombre,  Integer.parseInt(documento), Integer.parseInt(celular),
								 correo,  Integer.parseInt(edad));
					}
					else {
						anadir = false;
						System.out.print("\nQue id de habitacion desea reservar (ingrese el id): ");
						BufferedReader br17 = new BufferedReader (new InputStreamReader(System.in));
						String habitacion = br17.readLine();
						
						Cuarto cuarto = hotel.cuartoConsulta(habitacion);
						ArrayList<Cuarto> cuartos = new ArrayList<Cuarto>();
						cuartos.add(cuarto);
						Boolean anadir2 = true;
						while (anadir2) {
							System.out.print("\nDesea añadir mas cuartos (digite si o no): ");
							BufferedReader br20 = new BufferedReader (new InputStreamReader(System.in));
							String anadir_ent2 = br20.readLine();
							if (anadir_ent2.equals("si")) {
								System.out.println("\nIngrese el id del cuarto: ");
								br11 = new BufferedReader (new InputStreamReader(System.in));
								habitacion = br11.readLine();
								cuarto = hotel.cuartoConsulta(habitacion);
								cuartos.add(cuarto);
							}
							else {
								anadir2 = false;
							}
						}
						
						System.out.print("\nFecha inicial (dd/mm/yyyy): ");
						BufferedReader br18 = new BufferedReader (new InputStreamReader(System.in));
						String fechaInit = br18.readLine();
						
						System.out.print("\nFecha fin (dd/mm/yyyy): ");
						BufferedReader br19 = new BufferedReader (new InputStreamReader(System.in));
						String fechaFin = br19.readLine();
						
						hotel.crearReserva(huespedPrincipal.getDocumento(), fechaInit, fechaFin, huespedes, cuartos);
						
					}
				}
				
			}
			if (op==2) {
				System.out.println(hotel.listaCuartos());	
			}
			if (op==3) {
				System.out.println(hotel.listaMenu());
			}
			if (op==4) {
				System.out.print("\nIngrese la cedula del titular de la reserva: ");
				BufferedReader br24 = new BufferedReader (new InputStreamReader(System.in));
				String cc = br24.readLine();
				
				System.out.print("\nIngrese la fecha actual (dd/mm/yyyy): ");
				BufferedReader br25 = new BufferedReader (new InputStreamReader(System.in));
				String fechaActual = br25.readLine();
				System.out.println(hotel.generarCheckout(Integer.parseInt(cc), fechaActual));
			}
			if (op==5) {
				System.out.print("\nIngrese la cedula del titular de la reserva: ");
				BufferedReader br26 = new BufferedReader (new InputStreamReader(System.in));
				String CC = br26.readLine();
				System.out.println(hotel.listaConsumoReserva( Integer.parseInt(CC)));
			}
			if (op==6) {
				System.out.println(hotel.listaServicios());
			}
		}
		else {
			if (op==1) {
				System.out.println("\nIngrese el documento del huesped: ");
				BufferedReader br30 = new BufferedReader (new InputStreamReader(System.in));
				String documento = br30.readLine();
				
				System.out.println("\nIngrese la fecha (dd/mm/yyyy): ");
				BufferedReader br31 = new BufferedReader (new InputStreamReader(System.in));
				String fecha = br31.readLine();
				
				System.out.println("\nEl servicio esta pago? (si o no): ");
				BufferedReader br32 = new BufferedReader (new InputStreamReader(System.in));
				String pago_str = br32.readLine();
				Boolean pago = false;
				if (pago_str.equals("si")) {
					pago = true;
				}
				
				System.out.println("\nIngrese el tipo de servicio: ");
				BufferedReader br33 = new BufferedReader (new InputStreamReader(System.in));
				String tipo = br33.readLine();
				
				System.out.println("\nIngrese el valor del servicio: ");
				BufferedReader br34 = new BufferedReader (new InputStreamReader(System.in));
				String val = br34.readLine();
				
				hotel.registrarConsumo(Integer.parseInt(documento), fecha, pago, tipo, Integer.parseInt(val));
				
			}
			if (op==2) {
				System.out.println(hotel.listaMenu());
			}
			if (op==3) {
				System.out.println(hotel.listaServicios());
			}
		}
	}
	
	public static void main(String[] args) throws IOException, ParseException {
		
		hotel.cargarInformacionHotel();
		//hotel.guardarArchivo();
		
		while (true) {
			String rol = pedirUsuario();
			int op = 0;
			int salida = 0;
			if (rol.equals("administrador")) {
				salida = 10;
			}
			else if (rol.equals("recepcionista")) {
				salida = 7;
			}
			else {
				salida = 4;
			}
			while (op != salida) {
				mostrarOpcionesDisponibles(rol);
				System.out.print("\nPor favor digite la opción que desee realizar: ");
				BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
				String input = br.readLine();
				if(input == null) {
					System.out.println("\nLa entrada no puede estar vacia.");
				}
				else {
					try {
						op = Integer.parseInt(input);
						ejecutarOpciones(op, rol);
						System.out.print("\nPresione 'Enter' para continuar.");
						BufferedReader brStop = new BufferedReader(new InputStreamReader(System.in));
						try {
							String inputStop = brStop.readLine();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} catch (NumberFormatException nfe ) {
						System.out.println("La entrada debe ser un valor numérico.");
					}
					
				}
			}
			
		}
	}
	
	
	
}
