package modulo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Factura {
	
	//Atributos
	
	private int idFactura;
	private String fecha;
	private int valorImpuesto;
	private int valorTotal;
	private static int numeroFacturas;
	private Huesped huespedFactura;
	private ArrayList<Cuarto> cuartosFactura = new ArrayList<Cuarto>();
	private ArrayList<Consumo> consumos = new ArrayList<Consumo>();
	
	
	//Metodos
	
	public Factura(String fecha, Huesped huespedFactura, ArrayList<Cuarto> cuartosFactura) {
		numeroFacturas++;
		this.fecha = fecha;
		idFactura = numeroFacturas;
		this.cuartosFactura = cuartosFactura;
		this.huespedFactura = huespedFactura;
		
	}
	
	private void calcularValorFactura() {
		for (int i=0; i < consumos.size(); i++) {
			Consumo consumo = consumos.get(i);
			if (!(consumo.getPago())){
				valorTotal += consumo.getValor();
				valorImpuesto += consumo.getValor() * consumo.getImpuesto();
			}
		} 
	}
	
	public String generarTextoFactura() {
		calcularValorFactura();
		String respuesta = "Fecha " + fecha + "\n Numero de factura " + String.valueOf(idFactura);
		respuesta += "\nNombre Huesped " + huespedFactura.getNombre() + " CC " + String.valueOf(huespedFactura.getDocumento());
		respuesta += "\nCuarto " ;
		for (int i=0; i < cuartosFactura.size(); i++) {
			Cuarto cuarto = cuartosFactura.get(i);
			respuesta += cuarto.getId() + ", ";
		}
		respuesta = respuesta.substring(0,respuesta.length()-2);
		respuesta += "\n" + "-".repeat(20);
		respuesta += "\nConsumos:";
		for (int i=0; i < consumos.size(); i++) {
			Consumo consumo = consumos.get(i);
			if (!(consumo.getPago())){
				respuesta += "\n" + consumo.generarTextoFactura();
			}
		}
		int total = valorTotal + valorImpuesto;
		respuesta += "\n" + "-".repeat(20);
		respuesta += "\nSubtotal " + String.valueOf(valorTotal);
		respuesta += "\nValor impuestos " + valorImpuesto;
		respuesta += "\nTotal a Pagar " + total;
		
		return respuesta;
	}
	
	public void guardarFactura() {
		
		File archivo = new File("Factura_Huesped_"+ huespedFactura.getDocumento() + "_Numero_Factura_" + idFactura +".txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(archivo.getName()));
			writer.write(generarTextoFactura());
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
