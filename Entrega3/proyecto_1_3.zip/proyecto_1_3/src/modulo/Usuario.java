package modulo;

public class Usuario {
	
	//Atributos
	private String login;
	private String password;
	private String rol;
	
	//Metodos
	
	public Usuario(String login, String password, String rol) {
		
		this.login = login;
		this.password = password;
		this.rol = rol;
	}
	
	public String getLogin() {
		return login;
	}
	
	public String getPassword() {
		return password;
	}
	public String getRol() {
		return rol;
	}
}
