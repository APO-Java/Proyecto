package modulo;

public class Horario {
	
	private String horaApertura;
	private String horaCierre;
	private String dia;
	
	//Metodos
	
	public Horario (String horaApertura, String horaCierre, String dia) {
		this.horaApertura = horaApertura;
		this.horaCierre = horaCierre;
		this.dia = dia;
	}
	
	public String getHoraApertura() {
		return horaApertura;
	}
	public String getHoraCierre() {
		return horaCierre;
	}
	public String getDia() {
		return dia;
	}

}
