package modulo;

import java.util.ArrayList;
import java.util.Hashtable;

public class Restaurante {
	
	//Atributos
	
	private String ubicacion;
	private Hashtable<String, Comida> platos = new Hashtable<String, Comida>();
	private Hashtable<String, Bebida> bebidas = new Hashtable<String, Bebida>();
	private ArrayList<Horario> horarios = new ArrayList<Horario>();
	
	
	//Metodos
	
	public Restaurante(String ubicacion) {
		this.ubicacion = ubicacion;
	}
	
	public String getUbicacion() {
		return ubicacion;
		
	}
	
	public void agregarComida(Comida plato) {
		platos.put(plato.getNombre() ,plato);
	}
	public void agregarBebida(Bebida bebida) {
		bebidas.put( bebida.getNombre(), bebida);
	}
	public void agregarHorario(Horario horario) {
		horarios.add(horario);
	}
	
	public String listaComidas(){
		String texto = "";

		for (String key: platos.keySet()) {
			Comida comida =  platos.get(key);
			texto += "\nNombre " + comida.getNombre() + " Precio " + comida.getPrecio();
		}
		return texto;
	}
	public String listaBebidas(){
		String texto = "";

		for (String key: bebidas.keySet()) {
			Bebida bebida =  bebidas.get(key);
			texto += "\nNombre " + bebida.getNombre() + " Precio " + bebida.getPrecio();
		}
		return texto;
	}
	
}
