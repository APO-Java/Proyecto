package modulo;

public class TarifaDiaria {
	//Atributos
	
	private int precio;
	private String dia;
	
	public TarifaDiaria(String dia, int precio) {
		this.dia = dia;
		this.precio = precio;
	}
	
	public String getDia() {
		return dia;
	}
	
	public int getPrecio() {
		return precio;
	}

}
