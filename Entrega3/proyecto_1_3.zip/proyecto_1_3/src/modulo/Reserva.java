package modulo;

import java.util.ArrayList;

public class Reserva {
	//Atributos
	
	private Huesped huespedPrincipal;
	private String fechaInit;
	private String fechaFin;
	private ArrayList<Cuarto> cuartosReservados = new ArrayList<Cuarto>();
	private ArrayList<Huesped> huespedes = new ArrayList<Huesped>();
	private ArrayList<Consumo> serviciosConsumidos = new ArrayList<Consumo>();
	private Factura factura;
	
	//Metodos
	
	public Reserva(Huesped huespedPrincipal, String fechaInit, String fechaFin) {
		this.huespedPrincipal = huespedPrincipal;
		this.fechaInit = fechaInit;
		this.fechaFin = fechaFin;
	}
	
	public Huesped getHuespedPrincipal() {
		return huespedPrincipal;
	}
	
	public String getFechaInit() {
		return fechaInit;
	}
	
	public String getFechaFin() {
		return fechaFin;
	}
	
	public void agregarHuesped(Huesped huesped) {
		huespedes.add(huesped);
	}
	
	public void agregarServicio(Consumo consumo) {
		serviciosConsumidos.add(consumo);
	}
	
	public void agregarCuarto(Cuarto cuarto) {
		cuartosReservados.add(cuarto);
	}
	
	public ArrayList<Cuarto> getCuartos(){
		return cuartosReservados;
	}
	
	public void modificarOcupado(Cuarto cuarto, Boolean reservado) {
		cuarto.modificarReservado(reservado);
	}
	
	public String generarFactura(String fechaActual) {
		factura = new Factura(fechaActual, huespedPrincipal, cuartosReservados);
		factura.guardarFactura();
		return factura.generarTextoFactura();
	}
	public String listaConsumos(){
		String texto = "";

		for (Consumo consumo: serviciosConsumidos) {
			texto += "\nInformacion Consumos " + consumo.generarTextoFactura();
		}
		return texto;
	}
	
	
	
	
	
	
}
