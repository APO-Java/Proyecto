package modulo;

public class Bebida {
	//Atributos
	
	private int precio;
	private String nombre;
	private String lugarDisponibilidad; //habitacion, restaurante y/o ambos
	private String disponibilidadComida; //almuerzo, desayuno y/o comida permanente
	
	//Metodos
	
	public Bebida(String nombre, int precio, String lugarDisponibilidad, String disponibilidadComida ){
		this.nombre = nombre;
		this.precio = precio;
		this.lugarDisponibilidad = lugarDisponibilidad;
		this.disponibilidadComida = disponibilidadComida;
	}
	
	public int getPrecio() {
		return precio;
	}
	public String getNombre() {
		return nombre;
	}
	
	public String getLugarDisponibilidad() {
		return lugarDisponibilidad;
	}
	
	public String getDisponibilidadComida() {
		return disponibilidadComida;
	}
	
	
}
