package modulo;

public class Huesped {
	
	//Atributos
	
	private String nombre;
	private int documento;
	private int celular;
	private String correo;
	private int edad;
	
	//Metodos
	
	public Huesped(String nombre, int documento, int celular,
			String correo, int edad) {
		this.nombre = nombre;
		this.documento = documento;
		this.celular = celular;
		this.correo = correo;
		this.edad = edad;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public int getDocumento() {
		return documento;
	}
	
	public int getCelular() {
		return celular;
	}
	
	public String getCorreo() {
		return correo;
	}
	
	public int getEdad() {
		return edad;
	}
}
