package modulo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class Hotel {
	
	//Atributos
	private String nombre;
	//Ojito haga un hasmap
	private Hashtable<String, Usuario> usuarios = new Hashtable<String, Usuario>();
	private ArrayList<TipoCuarto> tiposCuartos = new ArrayList<TipoCuarto>();
	private Hashtable<String ,Cuarto> cuartos = new Hashtable<String ,Cuarto>();
	private Hashtable<Integer, Reserva> reservas = new Hashtable<Integer, Reserva>();
	private Hashtable<Integer, Huesped> huespedes = new Hashtable<Integer, Huesped>();
	private Hashtable<String, Servicio> servicios = new Hashtable<String, Servicio>();
	private Restaurante restaurante;
	
	//Metodos
	public Hotel(String nombre) {
		this.nombre = nombre;
		restaurante = new Restaurante("Hotel " + nombre + " Torre2");
		
	}
	
	public void cargarInformacionHotel() {
		try {
			cargarTiposCuarto();
			cargarCuartos();
			cargarServicios();
			cargarComidas();
			cargarBebidas();
			cargarUsuarios();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try (FileInputStream fis = new FileInputStream("./data/reservas.ser");
				ObjectInputStream ois = new ObjectInputStream(fis)) {
			reservas = (Hashtable<Integer, Reserva>) ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try (FileInputStream fis = new FileInputStream("./data/huespedes.ser");
				ObjectInputStream ois = new ObjectInputStream(fis)) {
			huespedes = (Hashtable<Integer, Huesped>) ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	private void cargarTiposCuarto() throws IOException {
		FileReader file = new FileReader("./data/tiposCuartos.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			var arrayCuarto = arrayCadenas[0].split(",");
			TipoCuarto tipoCuarto = new TipoCuarto(arrayCuarto[0],Integer.parseInt(arrayCuarto[1]));
			
			var arrayCadenas1 = arrayCadenas[1].split("-");
			for (int i=0; i < arrayCadenas1.length; i++) {
				var arrayCama = arrayCadenas1[i].split(",");
				Cama cama = new Cama(arrayCama[0],arrayCama[1],Integer.parseInt(arrayCama[2]));
				tipoCuarto.agregarCama(cama);
			}
			var arrayCadenas2 = arrayCadenas[2].split("-");
			for (int i=0; i < arrayCadenas2.length; i++) {
				var arrayTarifaDiaria = arrayCadenas2[i].split(",");
				TarifaDiaria tarifaDiaria = new TarifaDiaria(arrayTarifaDiaria[0], Integer.parseInt(arrayTarifaDiaria[1]));
				tipoCuarto.agregarModificarTarifaDiaria(tarifaDiaria);
			}
			var arrayCadenas3 = arrayCadenas[3].split("-");
			for (int i=0; i < arrayCadenas3.length; i++) {
				var arrayTarifaPeriodo = arrayCadenas3[i].split(",");
				TarifaPeriodo tarifaPeriodo = new TarifaPeriodo(Integer.parseInt(arrayTarifaPeriodo[1]), arrayTarifaPeriodo[0]);
				tipoCuarto.agregarModificarTarifaPeriodo(tarifaPeriodo);	
			
			}
			tiposCuartos.add(tipoCuarto);
			line = br.readLine();
		}
		br.close();
	}
	
	private void cargarCuartos() throws IOException {
		FileReader file = new FileReader("./data/habitaciones.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			String tipo = arrayCadenas[6];
			TipoCuarto tipoCuarto = null;
			for (int i=0; i < tiposCuartos.size(); i++) {
				if (tipo.equals(tiposCuartos.get(i).getTipo())) {
					tipoCuarto = tiposCuartos.get(i);
				}
			}
			Cuarto cuarto = new Cuarto(arrayCadenas[0],arrayCadenas[1], Boolean.valueOf(arrayCadenas[2]),  
					Boolean.valueOf(arrayCadenas[3]), Boolean.valueOf(arrayCadenas[4]), 
					Boolean.valueOf(arrayCadenas[5]), tipoCuarto);
			cuartos.put(cuarto.getId(), cuarto);
			line = br.readLine();
		}
		br.close();
	}
	public String listaServicios(){
		String texto = "";

		for (String key: servicios.keySet()) {
			Servicio servicio =  servicios.get(key);
			texto += "\nNombre " + servicio.getNombre() + " Precio " + servicio.getPrecio();
		}
		return texto;
	}
	
	public String listaUsuarios(){
		String texto = "";

		for (String key: usuarios.keySet()) {
			Usuario usuario =  usuarios.get(key);
			texto += "\nLogin " + usuario.getLogin() + " Password " + usuario.getPassword() + " Rol " + usuario.getRol();
		}
		return texto;
	}
	
	public String listaConsumoReserva(int CC) {
		return reservas.get(CC).listaConsumos();
	}
	
	public String listaCuartos(){
		String texto = "";

		for (String key: cuartos.keySet()) {
			Cuarto cuarto =  cuartos.get(key);
			texto += "\nId " + cuarto.getId() + " Ubicacion " + cuarto.getUbicacion() + " Reservado " + cuarto.getReservado();
		}
		return texto;
	}
	
	public String listaTiposHabitaciones(){
		String texto = "";

		for (TipoCuarto tipoCuarto: tiposCuartos) {
			texto += "\nTipo " + tipoCuarto.getTipo() + " Capacidad " + tipoCuarto.getCapacidad();
		}
		return texto;
	}
	
	public String listaMenu(){
		String texto = "";
		texto += "Comidas ";
		texto += restaurante.listaComidas();
		texto += "\nBebidas";
		texto += restaurante.listaBebidas();
		return texto;
	}
	
	
	public Cuarto cuartoConsulta(String id) {
		return cuartos.get(id);
	}
	
	
	
	public void cargarCuartosActualizados(String titulo) throws IOException {
		FileReader file = new FileReader(titulo);
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			String tipo = arrayCadenas[6];
			TipoCuarto tipoCuarto = null;
			for (int i=0; i < tiposCuartos.size(); i++) {
				if (tipo.equals(tiposCuartos.get(i).getTipo())) {
					tipoCuarto = tiposCuartos.get(i);
				}
			}
			//String id, String ubicacion,String tipo,  Boolean balcon, 
			//Boolean vista, Boolean cocina, int tarifa, Boolean reservado
			Cuarto cuarto = new Cuarto(arrayCadenas[0],arrayCadenas[1], Boolean.valueOf(arrayCadenas[2]),  
					Boolean.valueOf(arrayCadenas[3]), Boolean.valueOf(arrayCadenas[4]), 
					Boolean.valueOf(arrayCadenas[5]), tipoCuarto);
			cuartos.put(cuarto.getId(), cuarto);
			line = br.readLine();
		}
		br.close();
		String texto = "";
		for (Cuarto cuarto: cuartos.values()) {
			texto += cuarto.getId() + ";" + cuarto.getUbicacion() + ";" + cuarto.getBalcon() + ";"
					+ cuarto.getVista() + ";"+ cuarto.getCocina() + ";" + cuarto.getReservado() + ";"
					+ cuarto.getTipoCuarto().getTipo() + "\n";
		}
		texto = texto.substring(0,texto.length()-1);
		FileWriter archivoR = new FileWriter("./data/habitaciones.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(archivoR);
			writer.write(texto);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void cargarServicios()throws IOException {
		FileReader file = new FileReader("./data/servicios.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			Servicio servicio = new Servicio(arrayCadenas[0],Integer.parseInt(arrayCadenas[1]),Boolean.valueOf(arrayCadenas[2]));
			servicios.put(servicio.getNombre(), servicio);
			line = br.readLine();
		}
		br.close();	
	}
	
	private void cargarBebidas()throws IOException {
		FileReader file = new FileReader("./data/bebidas.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			Bebida bebida = new Bebida(arrayCadenas[0],Integer.parseInt(arrayCadenas[1]),arrayCadenas[2],arrayCadenas[3] );
			restaurante.agregarBebida(bebida);
			line = br.readLine();
		}
		br.close();	
	}
	private void cargarComidas()throws IOException {
		FileReader file = new FileReader("./data/comidas.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			Comida comida = new Comida(arrayCadenas[0],Integer.parseInt(arrayCadenas[1]),arrayCadenas[2],arrayCadenas[3] );
			restaurante.agregarComida(comida);
			line = br.readLine();
		}
		br.close();	
	}
	private void cargarUsuarios()throws IOException {
		FileReader file = new FileReader("./data/usuarios.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			Usuario usuario = new Usuario(arrayCadenas[0],arrayCadenas[1],arrayCadenas[2]);
			usuarios.put(usuario.getLogin(), usuario);
			line = br.readLine();
		}
		br.close();	
	}
	
	public void guardarArchivo() {
		try (FileOutputStream fos = new FileOutputStream("./data/reservas.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos)) {
			oos.writeObject(reservas);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try (FileOutputStream fos = new FileOutputStream("./data/huespedes.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos)) {
			oos.writeObject(huespedes);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	public Boolean crearHabitacion(String id, String ubicacion,String tipo,  Boolean balcon, 
									Boolean vista, Boolean cocina, Boolean reservado) throws IOException {
		TipoCuarto tipoCuarto = null;
		for (int i=0; i < tiposCuartos.size(); i++) {
			if (tipo.equals(tiposCuartos.get(i).getTipo())) {
				tipoCuarto = tiposCuartos.get(i);
			}
		}
		Cuarto cuarto = new Cuarto( id,  ubicacion,  balcon,  vista,cocina,  reservado,  tipoCuarto);	
		cuartos.put(cuarto.getId(), cuarto);
		
		FileReader archivo = new FileReader("./data/habitaciones.txt");
		BufferedReader br = new BufferedReader(archivo);
		String line = br.readLine();
		String texto = "";
		while (line != null) {
			texto += line + "\n";
			line = br.readLine();
		}
		br.close();
		
		texto += id + ";" +  ubicacion +";"+  balcon +";" +  vista+ ";" +cocina + ";" + reservado + ";" + tipo;
		
		FileWriter archivoR = new FileWriter("./data/habitaciones.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(archivoR);
			writer.write(texto);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cuartos.contains(cuarto);
	}
	
	public void registrarHuesped(String nombre, int documento, int celular, String correo, int edad) {
		Huesped huesped = new Huesped( nombre,  documento,  celular,  correo,  edad);
		huespedes.put(documento, huesped);
		guardarArchivo();
	}
	
	public String getDayOfWeek(LocalDate date, Locale locale) {
		DayOfWeek day = date.getDayOfWeek();
		return day.getDisplayName(TextStyle.FULL, locale);
		}
	
	public void crearReserva(int cedulaPrincipal, String fechaInit, String fechaFin, ArrayList<Huesped> huespedes,
			ArrayList<Cuarto> cuartos) {
		Huesped huespedPrincipal = this.huespedes.get(cedulaPrincipal);
		Reserva reserva = new Reserva(huespedPrincipal, fechaInit, fechaFin);
		
		for (int i=0; i< huespedes.size(); i++) {
			reserva.agregarHuesped(huespedes.get(i));
		}
		for (int i=0; i< cuartos.size(); i++) {
			reserva.agregarCuarto(cuartos.get(i));
			reserva.modificarOcupado(cuartos.get(i), true);
		}
		
		reservas.put(cedulaPrincipal, reserva);
		guardarArchivo();
	}
	
	public void registrarConsumo(int cedulaPrincipal, String fecha, Boolean pago, String tipoServicio,
			int valor) {
		Reserva reserva = reservas.get(cedulaPrincipal);
		Consumo consumo = new Consumo( fecha,  pago,  tipoServicio, valor);
		reserva.agregarServicio(consumo);
		guardarArchivo();
	}
	
	public void actualizarCrearComida(String nombrePlato, int nuevoPrecio, String lugarDisponibilidad, String disponibilidadComida) throws IOException {
		Comida comida = new Comida( nombrePlato, nuevoPrecio, lugarDisponibilidad,  disponibilidadComida);
		restaurante.agregarComida(comida);
		
		String texto = restaurante.textoArchivoComida();
		
		FileWriter archivoR = new FileWriter("./data/comidas.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(archivoR);
			writer.write(texto);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void actualizarCrearBebida(String nombreBebida, int nuevoPrecio, String lugarDisponibilidad, String disponibilidadComida) throws IOException {
		Bebida bebida = new Bebida( nombreBebida, nuevoPrecio, lugarDisponibilidad,  disponibilidadComida);
		restaurante.agregarBebida(bebida);
		String texto = restaurante.textoArchivoBebida();
		FileWriter archivoR = new FileWriter("./data/bebidas.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(archivoR);
			writer.write(texto);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void actualizarCrearServicio(String nombre, int precio, Boolean personal) throws IOException {
		Servicio servicio = new Servicio( nombre,  precio,  personal);
		servicios.put(servicio.getNombre(), servicio);
		String texto = "";
		for (Servicio servicio_r: servicios.values()) {
			texto += servicio_r.getNombre() + ";" + servicio_r.getPrecio() + ";" + servicio_r.getPersonal() + "\n";
		}
		texto = texto.substring(0,texto.length()-1);
		FileWriter archivoR = new FileWriter("./data/servicios.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(archivoR);
			writer.write(texto);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String generarCheckout(int cedula, String fechaActual) throws ParseException {
		Reserva reserva = reservas.get(cedula);
		if (reserva == null){
			return "No se encontro al cliente";
		}
		else {
			Hashtable <Integer, String> diasConvertidor = new Hashtable <Integer, String>();
			diasConvertidor.put(1, "L");
			diasConvertidor.put(2, "M");
			diasConvertidor.put(3, "X");
			diasConvertidor.put(4, "J");
			diasConvertidor.put(5, "V");
			diasConvertidor.put(6, "S");
			diasConvertidor.put(7, "D");
			ArrayList<Cuarto> cuartosReservados  = reserva.getCuartos();
			
			for (int i=0; i< cuartosReservados.size(); i++) {
				Cuarto cuarto = cuartosReservados.get(i);
				cuarto.modificarReservado(false);
				
				Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(reserva.getFechaInit());
				LocalDate ldate1 = date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				DayOfWeek day = ldate1.getDayOfWeek();
				
				Date date2 = new SimpleDateFormat("dd/MM/yyyy").parse(fechaActual);
				
				long diffInMillies = Math.abs(date2.getTime() - date1.getTime());
				long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
				
				int diaInicial = day.getValue();
				int precioTotal = 0;
				TipoCuarto tipoCuarto = cuarto.getTipoCuarto();
				if (diff == 3 && tipoCuarto.getTipo().equals("suite")) {
					precioTotal = tipoCuarto.consultaTarifa("Periodo", "TresDias");
				}
				else if (diff == 7 && !(tipoCuarto.getTipo().equals("suite"))) {
					precioTotal = tipoCuarto.consultaTarifa("Periodo", "Semanal");
				}
				else {
					precioTotal = 0;
					for (long j=0; j< diff; j++) {
						String StringDia = diasConvertidor.get(diaInicial);
						precioTotal += tipoCuarto.consultaTarifa("Diaria", StringDia);
						diaInicial ++;
						if (diaInicial>7) {
							diaInicial = 1;
						}
				}
				Consumo consumo = new Consumo(fechaActual, false, "Habitacion", precioTotal);
				reserva.agregarServicio(consumo);
				}
			}
		String facturita = reserva.generarFactura(fechaActual);
		reservas.remove(reserva.getHuespedPrincipal().getDocumento());
		guardarArchivo();
		return facturita;
		}
	}
	
	public String verificarUsuario(String login, String password) {
		if (usuarios.get(login) != null) {
			Usuario usuario = usuarios.get(login);
			if (usuario.getPassword().equals(password)) {
				return usuario.getRol();
			}
		}
		return "";	
	}
	
	public void agregarEliminarUsuario(String login, Boolean eliminar, String password, String rol) throws IOException{
		if (eliminar) {
			usuarios.remove(login);
			FileWriter archivoR = new FileWriter("./data/usuarios.txt");
			String texto = "";
			for (Usuario usuario: usuarios.values()) {
				texto +=  usuario.getLogin() + ";" + usuario.getPassword() + ";" + usuario.getRol() + "\n" ;
			}
			texto = texto.substring(0,texto.length()-1);
			BufferedWriter writer;
			try {
				writer = new BufferedWriter(archivoR);
				writer.write(texto);
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			Usuario usuario = new Usuario(login, password, rol);
			usuarios.put(login, usuario);
			
			FileReader archivo = new FileReader("./data/usuarios.txt");
			BufferedReader br = new BufferedReader(archivo);
			String line = br.readLine();
			String texto = "";
			while (line != null) {
				texto += line + "\n";
				line = br.readLine();
			}
			br.close();
			
			texto += login + ";" + password + ";" + rol ;
			
			FileWriter archivoR = new FileWriter("/data/usuarios.txt");
			BufferedWriter writer;
			try {
				writer = new BufferedWriter(archivoR);
				writer.write(texto);
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}


