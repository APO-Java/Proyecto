package modulo;

public class Cuarto {
	//Atributos
	
	private String id;
	private String ubicacion;
	private Boolean balcon;
	private Boolean vista;
	private Boolean cocina;
	private Boolean reservado;
	private TipoCuarto tipoCuarto;
	
	//Metodos
	
	public Cuarto(String id, String ubicacion, Boolean balcon, Boolean vista,
					Boolean cocina, Boolean reservado, TipoCuarto tipoCuarto) {
		this.id = id;
		this.ubicacion = ubicacion;
		this.balcon = balcon;
		this.vista = vista;
		this.cocina = cocina;
		this.reservado = reservado;
		this.tipoCuarto = tipoCuarto;
	}
	
	public String getId() {
		return id;
	}
	
	public String getUbicacion() {
		return ubicacion;
	}
	
	
	public Boolean getBalcon() {
		return balcon;
	}
	
	public Boolean getVista() {
		return vista;
	}
	
	public Boolean getCocina() {
		return cocina;
	}
	
	
	public Boolean getReservado() {
		return reservado;
	}
	
	public TipoCuarto getTipoCuarto() {
		return tipoCuarto;
	}
	
	public void modificarReservado(Boolean modificar) {
		reservado = modificar;
	}
	
	
}
