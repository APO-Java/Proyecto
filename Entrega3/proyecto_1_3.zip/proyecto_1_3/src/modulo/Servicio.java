package modulo;

public class Servicio {
	//Atributos
	private String nombre;
	private int precio;
	private Boolean personal;
	
	//Metodos
	
	public Servicio(String nombre, int precio, Boolean personal) {
		this.nombre = nombre;
		this.precio = precio;
		this.personal = personal;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public int getPrecio() {
		return precio;
	}
	
	public Boolean getPersonal() {
		return personal;
	}
	
}
