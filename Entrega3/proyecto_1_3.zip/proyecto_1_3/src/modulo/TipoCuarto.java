package modulo;

import java.util.ArrayList;
import java.util.Hashtable;

public class TipoCuarto {
	
	//Atributos
	private String tipo;
	private int capacidad;
	private ArrayList<Cama> camas = new ArrayList<Cama>();
	private Hashtable<String, TarifaDiaria> tarifasDiarias = new  Hashtable<String, TarifaDiaria>();
	private Hashtable<String, TarifaPeriodo> tarifasPeriodos = new  Hashtable<String, TarifaPeriodo>();
	
	//Metodos
	
	public TipoCuarto(String tipo, int capacidad) {
		this.tipo = tipo;
		this.capacidad = capacidad;
	}
	
	public int getCapacidad() {
		return capacidad;
	}
	
	public String getTipo() {
		return tipo;
	}
	
	public Boolean agregarModificarTarifaDiaria(TarifaDiaria tarifaDiaria) {
		ArrayList<String> dias = new ArrayList<String>();
		dias.add("L");
		dias.add("M");
		dias.add("X");
		dias.add("J");
		dias.add("V");
		dias.add("S");
		dias.add("D");
		
		if (dias.contains(tarifaDiaria.getDia())) {
			tarifasDiarias.put(tarifaDiaria.getDia(), tarifaDiaria);
			return true;
			
		}
		return false;
	}
		
	public Boolean agregarModificarTarifaPeriodo(TarifaPeriodo tarifaPeriodo) {
		
		if (tarifasPeriodos.get(tarifaPeriodo.getPeriodo()) == null) {
			tarifasPeriodos.put(tarifaPeriodo.getPeriodo(), tarifaPeriodo);
			return true;
		}
		return false;	
	}
	
	public int consultaTarifa(String tipo, String valor) {
		if (tipo.equals("Diaria")) {
			return tarifasDiarias.get(valor).getPrecio();
		}
		else {
			return tarifasPeriodos.get(valor).getPrecio();
		}
	}
	
	public void agregarCama(Cama cama) {
		camas.add(cama);
	 
	}
	
	
}
