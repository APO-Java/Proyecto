package modulo;

public class Cama {
	
	//Atributos
	
	private String tamano;
	private String user;
	private int numeroUser;
	
	//Metodos
	
	public Cama(String tamano, String user, int numeroUser) {
		this.tamano = tamano;
		this.user = user;
		this.numeroUser = numeroUser;
	}
	
	public String getTamano() {
		return tamano;
	}
	
	public String getUser() {
		return user;
	}
	
	public int getNumeroUser() {
		return numeroUser;
	}

}
