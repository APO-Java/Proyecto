package modulo;

public class Comida {
	
	//Atributos
	
	private int precio;
	private String nombre;
	private String lugarDisponibilidad;
	private String disponibilidadComida;
	
	//Metodos
	
	public Comida(String nombre, int precio, String 
					lugarDisponibilidad, String disponibilidadComida) {
		this.precio = precio;
		this.nombre = nombre;
		this.lugarDisponibilidad = lugarDisponibilidad;
		this.disponibilidadComida = disponibilidadComida;	
	}
	
	public int getPrecio() {
		return precio;
	}
	public String getNombre() {
		return nombre;
	}
	
	public String getLugarDisponibilidad() {
		return lugarDisponibilidad;
	}
	
	public String getDisponibilidadComida() {
		return disponibilidadComida;
	}

}
