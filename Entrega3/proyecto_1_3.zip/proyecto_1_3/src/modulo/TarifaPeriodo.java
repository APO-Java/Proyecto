package modulo;

public class TarifaPeriodo {
	
	//Atributos
	
	private int precio;
	private String periodo;
	
	//Metodos
	
	public TarifaPeriodo(int precio, String periodo) {
		this.precio = precio;
		this.periodo = periodo;
	}
	
	public int getPrecio() {
		return precio;
	}
	
	public String getPeriodo() {
		return periodo;
	}
	
	
	
}
