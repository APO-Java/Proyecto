package modulo;

public class Consumo {
	//Atributos
	
	private String fecha;
	private Boolean pago;
	private String tipoServicio;
	private double impuesto;
	private int valor;
	
	//Metodos
	
	public Consumo(String fecha, Boolean pago, String tipoServicio,
			int valor) {
		impuesto = 0.19;
		this.fecha = fecha;
		this.pago = pago;
		this.tipoServicio = tipoServicio;
		this.valor = valor;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public int getValor() {
		return valor;
	}
	
	public double getImpuesto() {
		return impuesto;
	}
	
	public Boolean getPago() {
		return pago;
	}
	
	
	public String generarTextoFactura() {
		double total = valor + valor*impuesto;
		return "Fecha: " + fecha + " Servicio: " + tipoServicio + " Valor: " 
	+ total ;
	}
	
}
